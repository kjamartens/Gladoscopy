"""
glados_pycromanager package initialization file.
"""

# No additional initialization needed for now.
from napari.utils.notifications import show_info

def show_hello_message():
    show_info('Hello, world!')