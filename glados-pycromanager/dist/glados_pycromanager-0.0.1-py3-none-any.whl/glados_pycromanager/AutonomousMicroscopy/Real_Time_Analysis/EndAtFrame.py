
def is_pip_installed():
    return 'site-packages' in __file__ or 'dist-packages' in __file__

if is_pip_installed():
    from glados_pycromanager.AutonomousMicroscopy.MainScripts import FunctionHandling
else:
    from MainScripts import FunctionHandling
from shapely import Polygon, affinity
import math
import numpy as np
import inspect
import dask.array as da
import time

# Required function __function_metadata__
# Should have an entry for every function in this file
def __function_metadata__():
    return { 
        "EndAtFrame": {
            "required_kwargs": [
                {"name": "LastFrame", "description": "Last frame after which it should be cut off", "default": 50, "type": int}
            ],
            "optional_kwargs": [
            ],
            "help_string": "Examplary method to influence the run",
            "display_name": "Example - influence the run by stopping it at a set frame",
            "run_delay": 0,
            "visualise_delay": 1000,
            "visualisation_type": "points", #'image', 'points', 'value', or 'shapes'
            "input":[
            ],
            "output":[
            ],
        }
    }


#-------------------------------------------------------------------------------------------------------------------------------
#Callable functions
#-------------------------------------------------------------------------------------------------------------------------------
class EndAtFrame():
    def __init__(self,core,**kwargs):
        print(core)
        self.initDone = 'Yea'
        #Check if we have the required kwargs
        class_name = inspect.currentframe().f_locals.get('self', None).__class__.__name__ #type:ignore
        [provided_optional_args, missing_optional_args] = FunctionHandling.argumentChecking(__function_metadata__(),class_name,kwargs) #type:ignore

        return None

    def run(self,image,metadata,shared_data,core,**kwargs):
        self.image = image
        self.metadata = metadata
        self.shared_data = shared_data
        self.kwargs = kwargs
        if self.metadata['Axes']['time'] >= int(self.kwargs['LastFrame']):
            #Abort and mark-finished the pycromanager acquisition
            shared_data._mdaModeAcqData.abort()
            shared_data._mdaModeAcqData.mark_finished()
            #Print a statement
            print(f"Ended at frame {self.metadata['Axes']['time']}")
    
    def end(self,core,**kwargs):
        return
    
    def visualise_init(self): 
        #No visualisation implemented
        layerName = 'None'
        layerType = 'points' #layerType has to be from image|labels|points|shapes|surface|tracks|vectors
        return layerName,layerType
    
    def visualise(self,image,metadata,core,napariLayer,**kwargs):
        #No visualisation implemented
        return
    