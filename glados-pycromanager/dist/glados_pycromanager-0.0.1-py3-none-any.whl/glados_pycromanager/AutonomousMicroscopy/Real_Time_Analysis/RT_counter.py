
def is_pip_installed():
    return 'site-packages' in __file__ or 'dist-packages' in __file__

if is_pip_installed():
    from glados_pycromanager.AutonomousMicroscopy.MainScripts import FunctionHandling
else:
    from MainScripts import FunctionHandling
from shapely import Polygon, affinity
import math
import numpy as np
import inspect
import dask.array as da
import time

# Required function __function_metadata__
# Should have an entry for every function in this file
def __function_metadata__():
    return { 
        "RealTimeCounter": {
            "required_kwargs": [
                {"name": "ReqKwarg1", "description": "First required kwarg", "default": 'DefaultKwarg', "type": str}
            ],
            "optional_kwargs": [
                {"name": "OptBool2", "description": "OptBool", "default": False, "type": bool}
            ],
            "help_string": "RT counter.",
            "display_name": "RT counter",
            "run_delay": 0,
            "visualise_delay": 100,
            "visualisation_type": "points", #'image', 'points', 'value', or 'shapes'
            "input":[
            ],
            "output":[
            ],
        }
    }


#-------------------------------------------------------------------------------------------------------------------------------
#Callable functions
#-------------------------------------------------------------------------------------------------------------------------------
class RealTimeCounter():
    def __init__(self,core,**kwargs):
        print('INITIALISING COUNTER REAL-TIME ANALYSIS')
        print(core)
        #Check if we have the required kwargs
        class_name = inspect.currentframe().f_locals.get('self', None).__class__.__name__ #type:ignore
        [provided_optional_args, missing_optional_args] = FunctionHandling.argumentChecking(__function_metadata__(),class_name,kwargs) #type:ignore

        print('in RT_counter at time '+str(time.time()))
        return None

    def run(self,image,metadata,shared_data,core,**kwargs):
        print('RUNNING COUNTER REAL-TIME ANALYSIS')
        if 'ImageNumber' in metadata:
            self.currentValue = metadata['ImageNumber']
            print("At frame: "+metadata['ImageNumber'])
        else:
            self.currentValue = metadata['Axes']['time']
            print("At axis-time: "+str(metadata['Axes']['time']))
    
    def end(self,core,**kwargs):
        print('ENDING COUNTER REAL-TIME ANALYSIS')
        return
    
    def visualise_init(self): 
        print('INITIALISING VISUALISATION COUNTER REAL-TIME ANALYSIS')
        layerName = 'RT counter'
        layerType = 'points' #layerType has to be from image|labels|points|shapes|surface|tracks|vectors
        return layerName,layerType
    
    def visualise(self,image,metadata,core,napariLayer,**kwargs):
        print('RUNNING VISUALISATION COUNTER REAL-TIME ANALYSIS')
        features = {
            'outputval': self.currentValue
        }
        textv = {
            'string': 'Current frame: {outputval:.0f}',
            'size': 10,
            'color': 'cyan',
            'translation': np.array([0, 0]),
            'anchor': 'upper_left',
        }
        napariLayer.data = [0, 256]
        napariLayer.features = features
        napariLayer.text = textv
        napariLayer.symbol = 'disc'
        napariLayer.size = 0
        napariLayer.selected_data = []